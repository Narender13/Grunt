# Sitecore microsite - How to Start

# Dependencies:
   1. Node
   2. Ruby
   3. Grunt
   4. Sass
   5. Compass

# How to start:
  - Open Command Prompt
  - type "npm install" and hit Enter - 
    This will install the required dependencies of the node modules


# How to Compile/Run -
  - Open Command Prompt
  - type "grunt" and hit Enter

# Watch for Changes and auto compile -
  - Open Command Prompt
  - type "grunt watch" and hit Enter